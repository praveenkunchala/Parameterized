package stepDefination;

import com.utility.Baseclass;

import cucumber.api.java.en.Then;

public class Acast_Page_Linkedin extends Baseclass {
	@Then("^Check the post on Linkden Page$")
	public void check_the_post_on_Linkden_Page() throws Throwable {
	    
	}

@Then("^Verify article share functionality on Linkden page$")
public void verify_article_share_functionality_on_Linkden_page() throws Throwable {
    
}

}
